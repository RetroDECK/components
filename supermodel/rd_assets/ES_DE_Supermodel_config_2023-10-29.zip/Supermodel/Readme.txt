Supermodel configuration files for use with ES-DE on Linux
2023-10-29

Place the Assets, Config and NVRAM directories in your model3 ROMs folder (default is ~/ROMs/model3/)
The files in the NVRAM directory provide some preconfigured game settings so that you don't need to enter the service menu and such to get the games to run.
This may however not work with all ROM dumps so if you have issues running your games then try to delete these files and see if that makes any difference.

Per-game button mappings have been customized in Config/Supermodel.ini, make further adjustments if needed.

The following page provides a lot of additional useful information on how to configure Supermodel:
https://forums.launchbox-app.com/files/file/3857-sega-model-3-supermodel-git-everything-pre-configured-inc-controls-for-pc-controller-mouse-light-guns-test-menus-configured-free-play-all-games-in-english-2-player-mouse-support-audio-adjusted-layout-imagesthe-whole-9-yards/?tab=comments

The configuration and NVRAM files included in this package are based on this work.
