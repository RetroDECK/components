#!/bin/bash

source "automation-tools/assembler.sh"

assemble flatpak_id "eu.vcmi.VCMI"

# Custom Commands

finalize
